//
//  DefaultViewAnimator.h
//  ZLSwipeableViewDemo
//
//  Created by Zhixuan Lai on 10/25/15.
//  Copyright © 2015 Zhixuan Lai. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZLSwipeableView.h"

@interface DefaultViewAnimator : NSObject <ZLSwipeableViewAnimator>

@end
