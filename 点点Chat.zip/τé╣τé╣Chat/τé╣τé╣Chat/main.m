//
//  main.m
//  点点Chat
//
//  Created by jiuxiaoming on 15/12/5.
//  Copyright © 2015年 jiuxiaoming. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
